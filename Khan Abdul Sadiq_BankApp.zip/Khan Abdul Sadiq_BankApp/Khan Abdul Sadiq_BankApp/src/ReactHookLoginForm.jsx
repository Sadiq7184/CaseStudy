import { useForm } from 'react-hook-form';
import React from 'react';
const ReactHookLoginForm=()=> {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const onSubmit = (data) => {
    console.log(data);
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
       <label>Username</label>
      <input type="text" {...register("uname", { required: true,minLength:6,maxLength:12})} />
      {errors.uname && <p>Username is required and length must be in(6,12) </p>}
      <br/>
      <label>Email</label>
      <input type="email" {...register("email", { required: true, pattern: /^\S+@\S+$/i })} />
      {errors.email && <p>Email is required and must be valid</p>}
      <br/>
      <label>Password</label>
      <input type="password" {...register("password", { required: true })} />
      {errors.password && <p>Password is required</p>}
      <button type="submit">Submit</button>
    </form>
  );
}
 
export default ReactHookLoginForm;